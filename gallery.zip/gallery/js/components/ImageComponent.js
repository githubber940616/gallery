function ImageComponent( { name, src, folder, type, upload, file, targetElement } ) {
	var {
		setStatus, 
		clearStatus,
		getColorStatusClasses, 
		processing,
		success,
		error,
		selected,
	} = StatusMixin;
	var config = {
		targetElement,
		data: {
			name,
			src,
			folder,
			type,
			upload,
			file,
		},
		append: true,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} .image {
					margin: 10px 5px;
					height: 140px;
					width: 140px;
					float: left;
					text-align: center;
					position: relative;
				}
				${prefix} .image__icon:hover img {
					opacity: 0.8;
				}
				${prefix} .image__icon {
					cursor: pointer;
					color: #ffdb2b;
					height: 105px;
					max-width: 93.33px;
					margin: 0 auto;
					overflow: hidden;
				}
				${prefix} .image__icon--uploading img {
					opacity: 0.3;
				}
				${prefix} .image__icon img {
					margin-top: 25px;
					height: 70px;
				}
				${prefix} .image:hover .image__icon {
					text-shadow: 1px 1px 2px #999;	
					color: #ffec3c;
				}
				${prefix} .image__name {
					font-size: 14px;
					font-weight: normal;
					cursor: pointer;	
				}
				${prefix} .image__name:hover {
					color: #333;
				}
				${prefix} .image__name .image__text-box {
					display: none;	
				}
				${prefix} .image__name .image__text-box input[type="text"] {
					width: 80px;
					text-align: center;
				}
				${prefix} .image__name label {
					cursor: pointer;
				}				
				${prefix} .image__name--rename label {
					display: none;
				}
				${prefix} .image__name--rename .image__text-box {
					display: inline;
				}
				${prefix} .image__status {
					position: absolute;
				    top: 75px;
				    right: 15px;
					font-size: 20px;
					cursor: pointer;
				}
				${prefix} .image__status--check,
				${prefix} .image__status--unchecked,
				${prefix} .image__status--processing,
				${prefix} .image__status--error,
				${prefix} .image__status--success {
					background-color: rgba(255, 255, 255, 0.9);
					border-radius: 1px;
					border: 1px solid #ddd;
					padding: 1px;
				}
				${prefix} .image__status .glyphicon {
					display: none;
				}
				${prefix} .image__status--check .glyphicon-check {
					color: #337ab7;	
					display: block;
				}
				${prefix} .image__status--unchecked .glyphicon-unchecked {
					color: #555;	
					display: block;
				}
				${prefix} .image__status--processing .glyphicon-repeat {
					color: #31708f;
					display: block;
				}
				${prefix} .image__status--error .glyphicon-exclamation-sign {
					color: #a94442;
					display: block;
				}
				${prefix} .image__status--success .glyphicon-ok-sign {
					color: #3c763d;
					display: block;
				}
				${prefix} .image button {
					display: none;
				}
				${prefix} [ref="form"] {
					display: none;
				}
			`;

			return style;
		},
		template: function() {
			var { name, src, folder, type, upload, } = this.data;
			var { PathInfo } = Tools;
			var justName = PathInfo.extract(name, 'name');
			var extension = PathInfo.extract(name, 'extension');

			var xml = `
				<div ref="image" class="image">
					<form ref="form"
						on-submit="editImageName">
						<input ref="typeInput" type="hidden" value="${type}" name="type" />
						<input ref="destFolderInput" type="hidden" value="" name="dest_folder" />
						<input ref="folderInput" type="hidden" value="${folder}" name="folder" />
						<input ref="extensionInput" type="hidden" value="${extension}" name="extension" />
						<input ref="oldNameInput" type="hidden" value="${name}" name="old_name" />
						<input ref="newNameInput" type="hidden" value="${name}" name="new_name" />
						${(upload) ? `<input ref="imageDataInput" type="hidden" value="" name="image_data" />` : ""}
					</form>
					<div ref="imageIcon" class="image__icon${(upload) ? " image__icon--uploading" : ""}"
						on-click="toggleSelect"
						on-dblclick="previewImage">
						<img ref="imageThumbnail" src="${src}" />						/>
					</div>
					<div ref="imageName" class="image__name">
						<label ref="imageLabel"
							on-dblclick="showRenameInput">${name}</label>
						<span class="image__text-box">
							<input ref="renameInput" type="text" value="${justName}" name="rename" 
								on-blur="editImageName"
							/>
							.${extension}
						</span>
					</div>
					<div ref="imageStatus" class="image__status">
						<span class="glyphicon glyphicon-check"></span>
						<span class="glyphicon glyphicon-unchecked"></span>
						<span class="glyphicon glyphicon-repeat rotate"></span>
						<span class="glyphicon glyphicon-ok-sign"></span>
						<span class="glyphicon glyphicon-exclamation-sign"></span>
					</div>
					<button ref="deleteBtn" type="button"
						on-click="deleteImage">Delete</button>
					<button ref="copyBtn" type="button"
						on-click="copyImage">Copy</button>
					<button ref="moveBtn" type="button"
						on-click="moveImage">Move</button>
					${(upload) ? `<button ref="uploadBtn" type="button" on-click="uploadImage">Upload</button>` : ""}	
				</div>
			`;	

			return xml;		
		},
		methods: {
			remove: function() {
				var { styleId } = this;
				var { $self } = this.$refs();

				$self.remove();
				if($(`[styleid="${styleId}"]`).length == 0) {
					$(`[itemid="${styleId}"]`).remove();
				}
			},
			setStatus, 
			clearStatus,
			getColorStatusClasses, 
			processing,
			success,
			error,
			selected,
			uploading: function() {
				this.setStatus({
					title: 'Uploading image...',
					placement: 'top',
					colorClass: 'info',
					statusClass: 'processing'
				});
			},
			getStatusSettings: function() {
				var { $image, $imageStatus } = this.$refs();
				var { colorClasses, statusClasses } = this.getColorStatusClasses();

				return {
					$container: $image,
					$iconContainer: $imageStatus,
					classPrefix: 'image__status--',
					colorClasses,
					statusClasses,
				}
			},
			getAjaxData: function(action) {
				var { $form } = this.$refs();
				var data = new FormData($form[0]);
				var phpFile = `php/process/image.php`;

				return {
					url: `${phpFile}?directory=Albums&action=${action}-image`,
					type: "POST",
					data,
					dataType: "json",
					processData: false,  
					contentType: false,  
				}
			},			
			uploadImage: function() {
				var config = this.getAjaxData('upload');
				var { _ } = Tools;
				var self = this;

				this.uploading();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						var {
							$imageDataInput,
							$imageThumbnail,
							$typeInput,
							$imageIcon,
							$uploadBtn,
						} = self.$refs();

						$typeInput.val('old');
						$imageDataInput.remove();
						$imageIcon.removeClass('image__icon--uploading');
						$imageThumbnail.attr('src', [ALBUMS, CURRENT_FOLDER, data.name].join("/"));
						$uploadBtn.remove();
						self.success(message);

						_.delay(function() {
							self.clearStatus();
						}, 4000);
					} else {
						self.error(message);

						_.delay(function(){
							self.remove();
						}, 10000)
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);

					_.delay(function(){
							self.remove();						
					}, 10000)
				};

				$.ajax(config);
			},
			copyImage: function() {
				var config = this.getAjaxData('copy');
				var { _ } = Tools;
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						self.success(message);
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};

				$.ajax(config);
			},
			renameImage: function() {
				var config = this.getAjaxData('rename');
				var { _, PathInfo } = Tools;
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						var { 
							$oldNameInput, 
							$newNameInput, 
							$renameInput, 
							$imageLabel,
						} = self.$refs();
						var { name } = data;
						var justName = PathInfo.extract(name, 'name');

						$oldNameInput.val(name);
						$newNameInput.val(name);
						$renameInput.val(justName);
						$imageLabel.text(name);
						self.success(message);
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};

				$.ajax(config);
			},
			deleteImage: function() {
				var config = this.getAjaxData('delete');
				var { _ } = Tools;
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						self.remove();
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};

				$.ajax(config);
			},
			moveImage: function() {
				var config = this.getAjaxData('move');
				var { _ } = Tools;
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						self.remove();
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};

				$.ajax(config);
			},
			editImageName: function() {
				var { 
					$imageName, 
					$imageLabel, 
					$extensionInput,
					$renameInput,
					$oldNameInput, 
					$newNameInput,
				} = this.$refs();
				var extension = $extensionInput.val();
				var oldName = $oldNameInput.val();
				var newName = $.trim($renameInput.val());
				var justName = newName;

				newName = [newName, extension].join(".");

				$renameInput.val(justName);
				$imageLabel.text(newName);
				$newNameInput.val(newName);

				$imageName.removeClass('image__name--rename');
				if(newName !== oldName) {
					this.renameImage();
				}
			},
			setImageData: function() {
				var { file } = this.data;
				var { $imageDataInput } = this.$refs();

				return new Promise(function(resolve, reject){
					var reader = new FileReader();

					reader.onload = function(e) {
						$imageDataInput.val(e.target.result);

						resolve();
					}
					reader.readAsDataURL(file);
				});
			},
		},
		events: {
			copyImage: function(e) {
				var { selectedFolder } = Tools.DirectoryModalCopying.data;
				var { $destFolderInput } = this.$refs();

				$destFolderInput.val(selectedFolder);
				this.copyImage();
			},
			moveImage: function(e) {
				var { selectedFolder } = Tools.DirectoryModalMoving.data;
				var { $destFolderInput } = this.$refs();

				$destFolderInput.val(selectedFolder);
				this.moveImage();
			},
			previewImage: function(e) {
				var { ImagePreview } = Tools;
				var { $oldNameInput, $imageThumbnail } = this.$refs();
				var src = $imageThumbnail.attr('src');
				var name = $oldNameInput.val();

				ImagePreview.show({ name, src });
			},
			toggleSelect: function(e) {
				var { $image } = this.$refs();

				if($image.hasClass('danger') || $image.hasClass('info') || $image.hasClass('success')) {
					return;
				}

				if($image.attr('selected')) {
					this.clearStatus();
				} else {
					this.selected();					
				}
			},
			deleteImage: function(e) {
				this.deleteImage();
			},
			editImageName: function(e) {
				if(e.type === 'submit') {
					e.preventDefault();	
				}

				this.editImageName();

				return false;
			},
			showRenameInput: function(e) {
				var { $imageName, $renameInput } = this.$refs();
				var value = $renameInput.val();

				$imageName.addClass('image__name--rename');
				$renameInput[0].selectionStart = 0;
				$renameInput[0].selectionEnd = value.length;
				$renameInput.focus();
			},
		},
		lifeCycle: {
			afterRender: function() {
				var { upload } = this.data;

				if(upload) {
					var self = this;

					this.setImageData().then(function(){
						self.uploadImage();
					});
				}
			}
		}
	};

	return new Component(config);
}