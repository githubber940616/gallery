function DirectoryModalComponent({
	targetElement,
	header,
	folders,
	selectedQuery,
}) {

	var config = {
		targetElement,
		data: {
			header,
			folders,
			selectedQuery,
			selectedFolder: '',
		},
		parentTag: {
			name: 'div',
			attributes: {
				class: 'modal fade',
				role: 'dialog'
			}
		},
		append: true,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} .directory-modal .modal-body {
					max-height: 180px;
					overflow: hidden;
				}
				${prefix} .directory-modal .modal-body:hover {
					overflow-x: hidden;
					overflow-y: scroll;
				}
			`;

			return style;
		},
		template: function() {
			var { header, folders } = this.data;
			var { icon, title } = header;
			var xml = `
				<div class="directory-modal modal-dialog modal-sm">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h3 class="modal-title text-center">
								<span class="glyphicon glyphicon-${icon}"></span>
								${title}
							</h3>
						</div>
						<div class="modal-body">
				 			<div ref="folderList" class="list-group">
				 				${(function(){
				 					var xml = ``;

				 					if(folders.length) {
				 						for(var i=0; i<folders.length; i++) {			 							
					 						var folder = folders[i];

											xml += `
												<a ref="folderListItem" href="#" 
													data-name="${folder}"
													on-click="clickSelectedItems"
													class="list-group-item">
													${folder}
												</a>
											`;
				 						}

				 					} else {
				 						xml +=`
											<a href="#" 
												data-name="${folder}"
												class="list-group-item disabled">
												No folders found...
											</a>
										`;
				 					}

				 					return xml;
				 				})()}
							</div>      	
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
						</div>
					</div>
				</div>
			`;

			return xml;
		},
		methods: {
			show: function() {
				var { $self } = this.$refs();

				$self.modal('show');
			},
			hide: function() {
				var { $self } = this.$refs();

				$self.modal('hide');
			},
		},
		events: {
			clickSelectedItems: function(e) {
				var { selectedQuery } = this.data;
				var selectedFolder = $(e.target).attr('data-name');

				this.hide();
				this.data.selectedFolder = selectedFolder;

				$(selectedQuery).click();
			},
		}
	};

	return new Component(config);
}