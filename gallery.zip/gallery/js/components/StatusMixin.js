var StatusMixin = {
	getColorStatusClasses: function() {
		var colorClasses = [
			'primary', 
			'danger', 
			'success', 
			'warning', 
			'info',
		];
		var statusClasses = [
			'check',
			'unchecked',
			'processing',
			'error',
			'success',
		];
		
		return {
			colorClasses,
			statusClasses,
		}				
	},
	setStatus: function(status) {
		this.clearStatus();
		var { 
			$container, 
			$iconContainer, 
			classPrefix, 
			colorClasses, 
			statusClasses,
		} = this.getStatusSettings();
		var { 
			title, 
			placement, 
			colorClass, 
			statusClass, 
		} = status;
		var { _ } = Tools;
		statusClasses = _.map(statusClasses, function(item) {
			return [classPrefix, item].join("");
		});
		statusClass = [classPrefix, statusClass].join("");

		_.pull(statusClasses, statusClass);
		$iconContainer.addClass(statusClass)
			.removeClass(statusClasses.join(" "));

		_.pull(colorClasses, colorClass);
		$container.addClass(colorClass)
			.removeClass(colorClasses.join(" "))
			.tooltip({
				placement,
				title,
			});	

	},
	clearStatus: function() {
		var { 
			$container, 
			$iconContainer, 
			colorClasses, 
			statusClasses,
			classPrefix, 
		} = this.getStatusSettings();
		
		statusClasses = _.map(statusClasses, function(item) {
			return [classPrefix, item].join("");
		});

		$container.removeAttr('selected');
		$container.removeClass(colorClasses.join(" "))
			.tooltip('destroy');			
		$iconContainer.removeClass(statusClasses.join(" "));				
	},
	processing: function() {
		this.setStatus({
			title: 'Processing...',
			placement: 'top',
			colorClass: 'info',
			statusClass: 'processing'
		});
	},
	success: function(message) {
		this.setStatus({
			title: message,
			placement: 'top',
			colorClass: 'success',
			statusClass: 'success'
		});
	},
	error: function(message) {
		this.setStatus({
			title: `Error: ${message}`,
			placement: 'top',
			colorClass: 'danger',
			statusClass: 'error'
		});
	},
	selected: function() {
		var { $container } = this.getStatusSettings();

		this.setStatus({
			title: 'Selected.',
			placement: 'top',
			colorClass: 'primary',
			statusClass: 'check'
		});
		$container.attr('selected', '');
	},	
};