function ImagePreviewComponent({ targetElement }) {
	var config = {
		targetElement,
		append: true,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} {
					display: none;
					position: fixed;
					width: 100%;
					height: 100%;
					top: 0;
					left: 0;
					right: 0;
					bottom: 0;
					z-index: 20;
				}				
				${prefix} .image-preview {
					position: fixed;
					width: 100%;
					height: 100%;
					top: 0;
					left: 0;
					right: 0;
					bottom: 0;
					z-index: 20;
				}
				${prefix} .image-preview__background {
					width: 100%;
					height: 100%;
					background-color: rgba(0, 0, 0, 0.5);
					margin: 0;
					position: fixed;
					top: 0;
					left: 0;
					right: 0;
					bottom: 0;
				}
				${prefix} .image-preview__modal {
					width: 520px;
					height: 520px;
					background-color: #fff;
					border: 1px solid #ddd;
					margin: 0 auto;
					margin-top: 70px;
					border-radius: 5px;
				}
				${prefix} .image-preview__modal__header {
					text-align: center;
				}
				${prefix} .image-preview__modal__body {
					padding: 10px;
				}
				${prefix} .image-preview__modal__footer {
					padding: 10px;
					text-align: right;
				}
				${prefix} .image-preview__image {
					max-width: 500px;
					border: 1px solid #eee;
					overflow: hidden;
				}
				${prefix} .image-preview__image img {
					height: 375px;
				}
			`;

			return style;
		},
		template: function() {
			var xml = `
				<div class="image-preview">
					<div class="image-preview__background">
						<div class="image-preview__modal">
							<div class="image-preview__modal__header">
								<h3 ref="imageName"></h3>
							</div>
							<div class="image-preview__modal__body">
								<div class="image-preview__image">
									<img ref="imageThumbnail" src="" />
								</div>
							</div>
							<div class="image-preview__modal__footer">
								<button ref="closeBtn" class="btn btn-default"
									on-click="closeModal">
									<span class="glyphicon glyphicon-remove"></span>
									Close
								</button>
							</div>			
						</div>
					</div>
				</div>
			`;

			return xml;
		},
		methods: {
			show: function({name, src}) {
				var { $self, $imageName, $imageThumbnail } = this.$refs();

				console.log({ $imageName, $imageThumbnail });

				$imageName.text(name);
				$imageThumbnail.attr('src', src);
				$self.fadeIn();
			}
		}, 
		events: {
			closeModal: function(e) {
				var { $self } = this.$refs();

				$self.fadeOut();
			}
		}
	};

	return new Component(config);
}