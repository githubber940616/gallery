function NavigationBarComponent({ 
	targetElement,
	buttons,
	folders,
	insideFolder, 
	selectorQuery,
}) {
	var config = {
		data: {
			buttons,
			folders,
			insideFolder,
			selectorQuery,
		},
		targetElement,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} .navigation-bar {
					height: 60px;
					background-color: #fff;
					border-bottom: 1px solid #ddd;
					box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
					position: fixed;
					top: 0;
					left: 0;
					right: 0;
					margin: 0;
					z-index: 10;
				}
				${prefix} .navigation-bar__box {
					max-width: 1170px;
					width: 100%;
					height: 100%;
					position: relative;
					margin: 0 auto;
				}
				${prefix} .navigation-bar__logo {
					float: left;
					height: 100%;
					padding: 10px 7px;
					padding-left: 20px;
				}
				${prefix} .navigation-bar__logo a {
					text-decoration: none;
					color: #555;
				}
				${prefix} .navigation-bar__logo a:hover {
					color: #999;
				}
				${prefix} .navigation-bar__logo a:hover span {
					border-color: #999;
					box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
				}
				${prefix} .navigation-bar__logo span, 
				${prefix} .navigation-bar__logo h2 {
					vertical-align: baseline;
					padding: 0;
					margin: 0;
				} 	
				${prefix} .navigation-bar__logo span {
					border: 2px solid #555;
					padding: 1px;
				}
				${prefix} .navigation-bar__label {
					display: inline-block;
				}
				${prefix} .navigation-bar__label h3 {
					margin-top: 16px;
					color: #666;
				}
				${prefix} .navigation-bar__icons {
					float: right;
					position: relative;
					height: 100%;
					padding: 0 5px;
				}
				${prefix} .navigation-bar__icons .separator {
					display: inline-block;
					border: 1px solid #ddd;
					height: 40px;
					vertical-align: middle;
					margin: 0 5px;
				}
				${prefix} .navigation-bar__icon {
					font-size: 20px;
					height: 100%;
					padding: 10px 2px;
					display: inline-block;
					text-align: center;
					color: #555;
				}
				${prefix} .navigation-bar__icon:hover {
					color: #999;
				}

				${prefix} .navigation-bar__icon:hover .glyphicon {
					border-color: #999;
				}
				${prefix} .navigation-bar__icon span {
					vertical-align: middle;
				}
				${prefix} .navigation-bar__icons .navigation-bar__icon>.glyphicon {
				    border: 2px solid #666;
				    padding: 2px;
				    border-radius: 5px;
				}
			`;

			return style;
		},
		template: function() {
			var { buttons, folders, insideFolder, } = this.data;
			var xml = `
				<div class="navigation-bar">
					<div class="navigation-bar__box">
						<div class="navigation-bar__logo">
							<a href="./">
								<h2>
									<span class="glyphicon glyphicon-picture"></span>
									Gallery
								</h2>
							</a>
						</div>
						<div class="navigation-bar__label">
							${
								(CURRENT_FOLDER) ? 
								`
								<h3 class="text-center">
									<span class="glyphicon glyphicon-menu-right"></span>
									${CURRENT_FOLDER}
								</h3>
								`
								: ""
							}
						</div>
						<div ref="btnContainer" class="navigation-bar__icons">
							<a ref="reloadBtn" 
								title="Reload page" 
								class="navigation-bar__icon" 
								href="#"
								on-click="reloadPage">
								<span class="glyphicon glyphicon-repeat"></span>
							</a>
							<a ref="uncheckedBtn" 
								title="Select all" 
								class="navigation-bar__icon" 
								href="#"
								on-click="selectAll">
								<span class="glyphicon glyphicon-unchecked"></span>
							</a>
							<a ref="checkBtn" 
								style="display: none;"
								title="Unselect all" 
								class="navigation-bar__icon" 
								href="#"
								on-click="unselectAll">
								<span class="glyphicon glyphicon-check"></span>
							</a>
							<span class="separator"></span>
						${
							(_.indexOf(buttons, 'create-folder') + 1) ? 
							`
							<a ref="createFolderBtn" 
								title="Add new folder" 
								class="navigation-bar__icon" 
								href="#"
								on-click="createFolder">
								<span class="glyphicon glyphicon-plus"></span>
							</a>
							`
							: ""
						}
						${
							(_.indexOf(buttons, 'add-photos') + 1) ? 
							`
							<input ref="fileInput" 
								type="file" 
								style="display: none;"
								multiple 
								on-change="uploadImage" 
							/> 
							<a ref="addPhotosBtn" 
								title="Add new photos" 
								class="navigation-bar__icon" 
								href="#"
								on-click="clickFileInput">
								<span class="glyphicon glyphicon-plus"></span>
							</a>
							`
							: ""
						}
						${
							(_.indexOf(buttons, 'move') + 1) ? 
							`
							<a ref="moveBtn" 
								title="Move selected image" 
								class="navigation-bar__icon" 
								href="#"
								on-click="showDirectoryModalMoving">
								<span class="glyphicon glyphicon-move"></span>
							</a>
							`
							: ""
						}
						${
							(_.indexOf(buttons, 'copy') + 1) ? 
							`
							<a ref="copyBtn" 
								title="Copy selected image" 
								class="navigation-bar__icon" 
								href="#"
								on-click="showDirectoryModalCopying">
								<span class="glyphicon glyphicon-copy"></span>
							</a>
							`
							: ""
						}
						${
							(_.indexOf(buttons, 'delete-image') + 1) ? 
							`
							<a ref="deleteImageBtn" 
								title="Delete selected image" 
								class="navigation-bar__icon" 
								href="#"
								on-click="deleteImage">
								<span class="glyphicon glyphicon-trash"></span>
							</a>
							`
							: ""
						}
						${
							(_.indexOf(buttons, 'delete-folder') + 1) ? 
							`
							<a ref="deleteFolderBtn" 
								title="Delete selected folder" 
								class="navigation-bar__icon" 
								href="#"
								on-click="deleteFolder">
								<span class="glyphicon glyphicon-trash"></span>
							</a>
							`
							: ""
						}							
							<span class="separator"></span>
						${
							(_.indexOf(buttons, 'play') + 1) ? 
							`
							<a ref="playBtn" 
								title="Play slideshow" 
								class="navigation-bar__icon" 
								href="#"
								on-click="playSlideShow">
								<span class="glyphicon glyphicon-play"></span>
							</a>
							`
							: ""
						}
							<a ref="fullScreenBtn" 
								title="Enter full screen mode" 
								class="navigation-bar__icon" 
								href="#"
								on-click="enterFullScreenMode">
								<span class="glyphicon glyphicon-resize-full"></span>
							</a>
							<a ref="exitFullScreenBtn" 
								title="Exit full screen mode" 
								class="navigation-bar__icon" 
								href="#"
								style="display: none;"
								on-click="exitFullScreenMode">
								<span class="glyphicon glyphicon-resize-small"></span>
							</a>
						${
							(_.indexOf(buttons, 'folders') + 1) ? 
							`
							<a ref="dropdownBtn" 
								title="Go to other folders" 
								class="navigation-bar__icon" 
								href="#"
							></a>
							`
							: ""
						}
						</div>
					</div>
				</div>
			`;

			return xml;
		},
		methods: {
			dropdownTemplate: function() {
				var { folders } = this.data;
				var xml = `
					<div class="dropdown">
						<button class="btn btn-default dropdown-toggle" 
							type="button" id="menu1" 
							data-toggle="dropdown">
							<span class="caret"></span>
						</button>
						<ul class="dropdown-menu dropdown-menu-right" 
							role="menu" 
							aria-labelledby="menu1">
							<li role="presentation">
								<a role="menuitem" href="./">
									Back to Gallery
								</a>
							</li>
							<li role="presentation" 
								class="divider"></li>
							${(function() {
								return folders.map(function(folder) {
									return `
										<li role="presentation">
											<a role="menuitem" 
												href="${['./album.php?name=', folder].join("")}">
												${folder}
											</a>
										</li>
									`
								}).join("");
							})()}
						</ul>
					</div>
				`;

				return xml;
			},
			exitFullScreenMode: function() {
				var { Screen } = Tools;

				Screen.exitFullScreenMode();
			},
			enterFullScreenMode: function() {
				var { Screen } = Tools;

				Screen.enterFullScreenMode();
			},
		},
		events: {
			selectAll: function(e) {
				var { $uncheckedBtn, $checkBtn } = this.$refs();
				var { selected } = this.data.selectorQuery;

				$uncheckedBtn.hide();
				$checkBtn.show();
				$(selected).click();
			},
			unselectAll: function(e) {
				var { $uncheckedBtn, $checkBtn } = this.$refs();
				var { unselected } = this.data.selectorQuery;

				$checkBtn.hide();
				$uncheckedBtn.show();
				$(unselected).click();
			},
			exitFullScreenMode: function(e) {
				var { $fullScreenBtn, $exitFullScreenBtn } = this.$refs();

				$exitFullScreenBtn.hide();	
				$fullScreenBtn.show();
				this.exitFullScreenMode();
			},
			enterFullScreenMode: function(e) {
				var { $fullScreenBtn, $exitFullScreenBtn } = this.$refs();

				$fullScreenBtn.hide();
				$exitFullScreenBtn.show();	
				this.enterFullScreenMode();
			},
			playSlideShow: function(e) {
				var { SlideShow } = Tools;

				SlideShow.open();
				this.enterFullScreenMode();
			},
			uploadImage: function(e) {
				var { files } = e.target;

				if(files.length) {
					for(var i=0; i<files.length; i++) {
						var file = files[i];
						var image = new ImageComponent({
							targetElement: document.getElementById('container'),
							name: file.name,
							src: window.URL.createObjectURL(file),
							folder: CURRENT_FOLDER,
							type: 'new',
							upload: true,
							file,
						});

						image.render();
					}
				}
			},
			clickFileInput: function(e) {
				var { $fileInput } = this.$refs();

				$fileInput.click();
			},
			reloadPage: function(e) {
				window.location.reload(true);
			},
			createFolder: function(e) {
				var folder = new FolderComponent({
					name: 'New Folder',
					type: 'new',
					targetElement: document.getElementById('container'),
				});

				folder.render();
			},
			deleteFolder: function(e) {
				var $element = $(`#container .folder[selected] [ref="deleteBtn"]`)

				$element.click();
			},
			showDirectoryModalCopying: function(e) {
				var { DirectoryModalCopying } = Tools;

				DirectoryModalCopying.show();
			},
			showDirectoryModalMoving: function(e) {
				var { DirectoryModalMoving } = Tools;

				DirectoryModalMoving.show();
			},
			deleteImage: function(e) {
				var $element = $(`#container .image[selected] [ref="deleteBtn"]`)

				$element.click();
			},
		},
		lifeCycle: {
			afterRender: function() {
				var { insideFolder } = this.data;

				if(insideFolder) {
					var { $dropdownBtn } = this.$refs();
					var xml = this.dropdownTemplate();

					$dropdownBtn.html(xml);					
				}
			},
		}
	}

	return new Component(config);
}