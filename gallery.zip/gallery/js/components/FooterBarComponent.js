function FooterBarComponent({
	targetElement,
	selectorQuery,
}) {
	var config = {
		targetElement,
		data: {
			selectorQuery,
		},
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} .footer-bar {
					height: 60px;
					background-color: #fff;
					border-bottom: 1px solid #ddd;
					box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
					position: fixed;
					bottom: 0;
					left: 0;
					right: 0;
					margin: 0;
					z-index: 10;
				}
				${prefix} .footer-bar__box {
					max-width: 1170px;
					width: 100%;
					height: 100%;
					position: relative;
					margin: 0 auto;
					text-align: center;
				}
				${prefix} .footer-bar__buttons {
					padding: 10px;
				}
			`;

			return style;			
		},
		template: function() {
			var xml = `
				<div class="footer-bar">
					<div class="footer-bar__box">
						<div class="footer-bar__buttons">
							<button ref="selectAllBtn" class="btn btn-default"
								on-click="selectAll">
								<span class="glyphicon glyphicon-check"></span>
								Select All
							</button>
							<button ref="unselectAllBtn" class="btn btn-default"
								on-click="unselectAll">
								<span class="glyphicon glyphicon-unchecked"></span>
								Unselect All
							</button>
						</div>
					</div>
				</div>
			`;

			return xml;
		},
		events: {
			selectAll: function(e) {
				var { selected } = this.data.selectorQuery;
				$(selected).click();
			},
			unselectAll: function(e) {
				var { unselected } = this.data.selectorQuery;
				$(unselected).click();
			}
		}
	};
	
	return new Component(config);
}