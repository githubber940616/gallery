function SlideShowComponent({
	targetElement,
}) {
	var config = {
		targetElement,
		data: {
			items: [],
		},
		append: true,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} {
					display: none;
				}
				${prefix} .slideshow-container {
					min-width: 800px;
					min-height: 600px;
					width: 100%;
					height: 100%;
					position: fixed;
					z-index: 30;
					top: 0;
					left: 0;
					right: 0;
					bottom: 0;
				}
				${prefix} .slideshow-container .btn {
					position: absolute;
					right: 10px;
					top: 10px;
					z-index: 31;
				    display: block;
				    background: none;
				    border: none;
				    color: #fff;
				}
				${prefix} .slideshow-container .item img {
					height: 100%;
					width: 100%;
				}
			`;

			return style;
		},
		template: function() {
			var xml = `
				<div class="slideshow-container">
				    <button ref="closeBtn" class="btn btn-default btn-lg" 
				        on-click="close">
				        <span class="glyphicon glyphicon-remove"></span>
				    </button>
				    <div ref="slideShow" id="slideshow" class="carousel slide">
				        <ol ref="carouselIndicators" class="carousel-indicators"></ol>

				        <div ref="carouselInner" class="carousel-inner" role="listbox"></div>
				        <a class="left carousel-control" href="#slideshow" role="button" data-slide="prev">
				            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				            <span class="sr-only">Previous</span>
				        </a>
				        <a class="right carousel-control" href="#slideshow" role="button" data-slide="next">
				            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				            <span class="sr-only">Next</span>
				        </a>
				    </div>
				</div>
			`;

			return xml;
		},
		methods: {
			exitFullScreenMode: function() {
				var { Screen } = Tools;

				Screen.exitFullScreenMode();
			},
			enterFullScreenMode: function() {
				var { Screen } = Tools;

				Screen.enterFullScreenMode();
			},
			getAjaxData: function(action) {
				var { $form } = this.$refs();
				var data = { data: 'blank' };
				var phpFile = `php/process/image.php`;

				return {
					url: `${phpFile}?directory=Albums&action=${action}-image&folder=${CURRENT_FOLDER}`,
					type: "POST",
					data,
					dataType: "json",
					processData: false,  
					contentType: false,  
				}
			},		
			setItems: function(data) {
				var { _ } = Tools;

				this.data.items = _.map(data, function(item) {
					return {
						name: item,
						src: [ALBUMS, CURRENT_FOLDER, item].join("/"),
					}
				});
			},
			fetchItemsData: function() {
				var config = this.getAjaxData('get-all');
				var { _ } = Tools;
				var self = this;
				var { $self, $slideShow } = this.$refs();

				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						self.setItems(data);
						self.renderItems();
						self.enterFullScreenMode();
						$self.fadeIn();
						$slideShow.carousel({ interval: 5000, pause: false });
					} else {
						alert(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					alert(message);
				};

				$.ajax(config);								
			},
			indicatorTemplate: function({ index, active }) {
				var xml = `
		            <li data-target="#slideshow" 
		            	data-slide-to="${index}" 
		            	${(active) ? ` class="active"` : ""}></li>
				`;

				return xml;
			},
			itemTemplate: function({ name, src, active }) {
				var xml = `
			        <div class="item${(active) ? " active" : ""}">
			            <img src="${src}" />
			            <div class="carousel-caption">
			                <h3>${name}</h3>
			            </div>
			        </div>
				`;

				return xml;
			},
			renderItems: function() {
				var { items } = this.data;			
				var { $carouselInner, $carouselIndicators } = this.$refs();
				var itemsXml = ``;
				var indicatorsXml = ``;

				for(var i=0; i<items.length; i++) {
					var active = (i===0);
					var { name, src, } = items[i];

					itemsXml += this.itemTemplate({
						active,
						name,
						src,
						index: i,
					});
					indicatorsXml += this.indicatorTemplate({
						active,
						index: i,
					});
				}

				$carouselInner.html(itemsXml);
				$carouselIndicators.html(indicatorsXml);
			},
			open: function() {
				this.fetchItemsData();
			},
		},
		events: {
			close: function(e) {
				var { $self } = this.$refs();

				this.exitFullScreenMode();
				$self.fadeOut();
			},
		}
	};

	return new Component(config);
}