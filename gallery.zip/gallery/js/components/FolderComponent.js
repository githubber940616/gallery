function FolderComponent( { name, type, targetElement } ) {
	var {
		setStatus, 
		clearStatus,
		getColorStatusClasses, 
		processing,
		success,
		error,
		selected,
	} = StatusMixin;

	var  config = {
		targetElement,
		data: {
			name,
			type,
		},
		append: true,
		style: function() {
			var { styleId } = this;
			var prefix = `[styleid="${styleId}"]`;
			var style = `
				${prefix} .folder {
					margin: 10px 5px;
					height: 140px;
					width: 140px;
					float: left;
					text-align: center;
					position: relative;
				}
				${prefix} .folder__icon {
					font-size: 70px;
					cursor: pointer;
					color: #ffdb2b;
					height: 105px;
				}
				${prefix} .folder__icon .glyphicon {
					margin-top: 25px;
				}
				${prefix} .folder .folder__icon:hover {
					text-shadow: 1px 1px 2px #999;	
					color: #ffec3c;
				}
				${prefix} .folder__name {
					font-size: 14px;
					font-weight: normal;
					cursor: pointer;	
				}
				${prefix} .folder__name:hover {
					color: #333;
				}
				${prefix} .folder__name input[type=text] {
					width: 100px;
					text-align: center;
					display: none;
				}
				${prefix} .folder__name label {
					cursor: pointer;
				}	
				${prefix} .folder__name--rename label {
					display: none;
				}
				${prefix} .folder__name--rename input[type="text"] {
					display: inline;
				}
				${prefix} .folder__status {
					position: absolute;
				    top: 75px;
				    right: 15px;
					font-size: 20px;
					cursor: pointer;
				}
				${prefix} .folder__status--check,
				${prefix} .folder__status--unchecked,
				${prefix} .folder__status--processing,
				${prefix} .folder__status--error,
				${prefix} .folder__status--success {
					background-color: rgba(255, 255, 255, 0.9);
					border-radius: 1px;
					border: 1px solid #ddd;
					padding: 1px;
				}
				${prefix} .folder__status .glyphicon {
					display: none;
				}
				${prefix} .folder__status--check .glyphicon-check {
					color: #337ab7;	
					display: block;
				}
				${prefix} .folder__status--unchecked .glyphicon-unchecked {
					color: #555;	
					display: block;
				}
				${prefix} .folder__status--processing .glyphicon-repeat {
					color: #31708f;
					display: block;
				}
				${prefix} .folder__status--error .glyphicon-exclamation-sign {
					color: #a94442;
					display: block;
				}
				${prefix} .folder__status--success .glyphicon-ok-sign {
					color: #3c763d;
					display: block;
				}
				${prefix} .folder button {
					display: none;
				}
				${prefix} [ref="form"] {
					display: none;
				}
			`;

			return style;
		},
		template: function() {
			var { name, type } = this.data;
			var xml = `
				<div ref="folder" class="folder">
					<form ref="form" on-submit="editFolderName">
						<input ref="typeInput" type="hidden" value="${type}" name="type" />
						<input ref="oldNameInput" type="hidden" value="${name}" name="old_name" />
						<input ref="newNameInput" type="hidden" value="${name}" name="new_name" />
					</form>
					<div ref="folderIcon" class="folder__icon"
						on-click="toggleSelect"
						on-dblclick="openFolder">
						<span class="glyphicon glyphicon-folder-open"></span>
					</div>
					<div ref="folderName" class="folder__name">
						<label ref="folderLabel"
							on-dblclick="showRenameInput">${name}</label>
						<input ref="renameInput" type="text" value="${name}" name="rename" 
							on-blur="editFolderName" />
					</div>
					<div ref="folderStatus" class="folder__status">
						<span class="glyphicon glyphicon-check"></span>
						<span class="glyphicon glyphicon-unchecked"></span>
						<span class="glyphicon glyphicon-repeat rotate"></span>
						<span class="glyphicon glyphicon-ok-sign"></span>
						<span class="glyphicon glyphicon-exclamation-sign"></span>
					</div>
					<button ref="deleteBtn" type="button"
						on-click="deleteFolder">Delete</button>
				</div>				
			`;

			return xml;
		},
		methods: {
			remove: function() {
				var { styleId } = this;
				var { $self } = this.$refs();

				$self.remove();
				if($(`[styleid="${styleId}"]`).length == 0) {
					$(`[itemid="${styleId}"]`).remove();
				}
			},
			setStatus, 
			clearStatus,
			getColorStatusClasses, 
			processing,
			success,
			error,
			selected,			
			getStatusSettings: function() {
				var { $folder, $folderStatus } = this.$refs();
				var { colorClasses, statusClasses } = this.getColorStatusClasses();

				return {
					$container: $folder,
					$iconContainer: $folderStatus,
					classPrefix: 'folder__status--',
					colorClasses,
					statusClasses,
				}
			},
			getAjaxData: function(action) {
				var { $form } = this.$refs();
				var data = new FormData($form[0]);
				var phpFile = `php/process/folder.php`;

				return {
					url: `${phpFile}?directory=Albums&action=${action}-folder`,
					type: "POST",
					data,
					dataType: "json",
					processData: false,  
					contentType: false,  
				}
			},
			createFolder: function() {
				var config = this.getAjaxData('create');
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						var { _ } = Tools;
						var { 
							$typeInput, 
							$oldNameInput, 
							$newNameInput, 
							$renameInput, 
							$folderLabel,
						} = self.$refs();
						var { name } = data;

						$typeInput.val('old');
						$oldNameInput.val(name);
						$newNameInput.val(name);
						$renameInput.val(name);
						$folderLabel.text(name);
						self.success(message);

						_.delay(function(){
							self.clearStatus();
						}, 4000)						
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				$.ajax(config);
			},
			renameFolder: function() {
				var config = this.getAjaxData('rename');
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						var { _ } = Tools;
						var { 
							$oldNameInput, 
							$newNameInput, 
							$renameInput, 
							$folderLabel,
						} = self.$refs();
						var { name } = data;

						$oldNameInput.val(name);
						$newNameInput.val(name);
						$renameInput.val(name);
						$folderLabel.text(name);
						self.success(message);
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};
				
				$.ajax(config);
			},
			deleteFolder: function() {
				var config = this.getAjaxData('delete');
				var self = this;

				self.processing();
				config.success =  function(response, status, xhr) {
					var { status, message, data } = response;
					
					if(status === 'success') {
						self.remove();
					} else {
						self.error(message);
					}		
				};

				config.error = function(xhr, status, error) {
					var message = `${status} ${error}`;

					self.error(message);
				};

				config.complete = function(xhr, status) {
					_.delay(function(){
						self.clearStatus();
					}, 4000);											
				};

				$.ajax(config);
			},
			editFolderName: function() {
				var { 
					$folderName, 
					$folderLabel, 
					$renameInput,
					$oldNameInput, 
					$newNameInput, 
					$typeInput,
				} = this.$refs();
				var type = $typeInput.val();
				var newName = $.trim($renameInput.val());
				var oldName = $oldNameInput.val();

				$folderLabel.text(newName);
				$renameInput.val(newName);
				$newNameInput.val(newName);

				$folderName.removeClass('folder__name--rename');
				if(type==='new') {
					this.createFolder();
				}
				if(type==='old') {
					if(newName !== oldName) {
						this.renameFolder();
					}
				}
			},
		},
		events: {
			openFolder: function(e) {
				var { host, pathname } = window.location;
				var { name } = this.data;
				var phpFile = 'album.php';
				var redirectPath = [phpFile, '?name=', name].join("");

				window.location.href = redirectPath;
			},
			deleteFolder: function(e) {
				this.deleteFolder();
			},
			toggleSelect: function(e) {
				var { $folder } = this.$refs();

				if($folder.hasClass('danger') || $folder.hasClass('info') || $folder.hasClass('success')) {
					return;
				}

				if($folder.attr('selected')) {
					this.clearStatus();
				} else {
					this.selected();					
				}
			},
			editFolderName: function(e) {
				if(e.type === 'submit') {
					e.preventDefault();	
				}

				this.editFolderName();

				return false;
			},
			showRenameInput: function(e) {
				var { $folderName, $renameInput } = this.$refs();
				var value = $renameInput.val();

				$folderName.addClass('folder__name--rename');
				$renameInput[0].selectionStart = 0;
				$renameInput[0].selectionEnd = value.length;
				$renameInput.focus();
			},
		},
		lifeCycle: {
			afterRender: function() {
				var { type } = this.data;

				if(type==='new') {
					var { $folderLabel } = this.$refs();

					$folderLabel.dblclick();					
				}
				console.log(`Finished creating component: ${this.componentId}`);

				return this;
			}
		}
	}

	return new Component(config);
}