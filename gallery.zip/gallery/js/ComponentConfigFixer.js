var ComponentConfigFixer = {
	fix: function(config) {
		var { 
			targetElement, 
			append,
			data, 
			parentTag, 
			style, 
			template, 
			events, 
			methods, 
			lifeCycle
		} = config;
		var repairedConfig = this.repairConfigs(config);

		return repairedConfig;
	},
	repairConfig: function(property, config) {
		var self = this;

		return self[property](config);
	},
	repairConfigs: function(config) {
		var keys = Object.keys(ComponentConfig);
		var repairedConfig = {}

		for(var i=0; i<keys.length; i++) {
			var key = keys[i];

			repairedConfig[key] = this.repairConfig(key, config[key])
		}

		return repairedConfig;
	},
	targetElement: function(config) {
		var { targetElement } = ComponentConfig;
		config = ($(config).length) ? config : undefined;

		return config;
	},
	append: function(config) {
		var { append } = ComponentConfig;
		
		config = (config && (typeof config === 'boolean')) ? config : append;

		return config;
	},
	data: function(config) {
		var { data } = ComponentConfig;
		config = (config && (typeof config === 'object')) ? config : data;

		return config;
	},
	parentTag: function(config) {
		var { name, attributes } = ComponentConfig.parentTag;

		if(config && (typeof config === 'object')) {
			var cfg_name = config.name;
			var cfg_attributes = config.attributes;

			config.name = (cfg_name && (typeof cfg_name === 'string')) ? cfg_name : name;
			config.attributes = attributes;

			if(cfg_attributes && (typeof cfg_attributes === 'object')) {
				var keys = Object.keys(cfg_attributes);

				if(keys.length) {
					config.attributes = cfg_attributes;
				}
			}

		} else {
			config = ComponentConfig.parentTag;
		}

		return config;
	},
	style: function(config) {
		var { style } = ComponentConfig;
		config = (typeof config === 'function') ? config : undefined;
		
		return config;
	},
	template: function(config) {
		var { template } = ComponentConfig;
		config = (config && (typeof config === 'function')) ? config : template;
		
		return config;
	},
	setCfg: function(type, config) {
		var keys = Object.keys(config);

		for(var i=0; i<keys.length; i++) {
			var key = keys[i];
			var fn = config[key];

			if(fn && (typeof fn === 'function')) {
				config[key] = fn;
			} else {
				var consoleError = function() { 
					console.error(`${type}.${key} is not a function.`); 
				};					

				config[key] = consoleError;
				consoleError();
			}
		}

		return config;
	},
	events: function(config) {
		var { events } = ComponentConfig;

		if(config && (typeof config === 'object')) {
			config = this.setCfg('events', config);
		} else {
			config = events;
		}

		return config;
	},
	methods: function(config) {
		var { methods } = ComponentConfig;

		if(config && (typeof config === 'object')) {
			config = this.setCfg('methods', config);
		} else {
			config = methods;
		}

		return config;
	},
	lifeCycle: function(config) {
		var { lifeCycle } = ComponentConfig;

		if(config && (typeof config === 'object')) {
			var { beforeRender, afterRender } = config;
			var consoleError = function(method) { 
				console.error(`this.${method} is not a function.`); 
			};					

			if(typeof beforeRender !== 'function') {
				if(beforeRender) {
					consoleError('beforeRender');
				}
				config.beforeRender = lifeCycle.beforeRender;
			}
			if(typeof afterRender !== 'function') {
				if(afterRender) {
					consoleError('afterRender');
				}
				config.afterRender = lifeCycle.afterRender;
			}
		} else {
			config = lifeCycle;
		}

		return config;
	},
}