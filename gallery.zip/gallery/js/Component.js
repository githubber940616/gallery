function Component(config = ComponentConfig) {
	config = ComponentConfigFixer.fix(config);
	var {
		targetElement,
		data,
		parentTag,
		style,
		template,
		events,
		methods,
		append,
		lifeCycle,
	} = config;

	this.parentTag = parentTag;
	this.append = append;
	this.data = data;
	this.targetElement = targetElement;
	this.template = template;
	this.style = style;
	this.events = events;
	this.methods = methods;
	this.componentId;
	this.styleId;
	this.parent;
	this.lifeCycle = lifeCycle;

	this.setParentComponent = function(component) {
		this.parent = component;
	}

	this.registerLifeCycle = function() {
		var { lifeCycle } = this;
		var lifeCycleKeys = Object.keys(lifeCycle);
		var forbiddenKeys = Object.keys(this);
		var self = this;

		for(var i=0; i<lifeCycleKeys.length; i++) {
			var key = lifeCycleKeys[i];

			if(key in forbiddenKeys) {

			} else {
				self[key] = lifeCycle[key];
			}
		}

		return this;
	}

	this.generateComponentId = function() {
		 function randomNumberBetween(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min; 
		}

		this.componentId = `cid_${Date.now()}_${randomNumberBetween(1000, 9999)}`;
		
		return this;
	}

	this.generateStyleId = function() {
		var { style } = this;
		var styleId = 'no-style';

		if(typeof style === 'function') {
			var cssText = Reflect.apply(style, this, []);
			var sha1 = new Hasher('SHA-1');
			
			styleId = sha1.hash(cssText);
		}

		return styleId;
	}

	this.styleExists = function() {
		var { styleId } = this;

		return $(`style[itemid="${styleId}"]`).length;
	}

	this.renderStyle = function() {
		var { style, styleId } = this;

		if(typeof style === 'function') {
			var xml = `
				<style itemid="${styleId}">
					${Reflect.apply(style, this, [])}
				</style>
			`;
			
			if(!this.styleExists()) {
				$(`body`).prepend(xml);
			}				
		}

		return this;
	}

	this.serializeAttributes = function(attributes) {
		var serialized = [];
		var keys = Object.keys(attributes);

		for(var i=0; i<keys.length; i++) {
			var key = keys[i];

			serialized.push(`${key.toLowerCase()}="${attributes[key]}"`);
		}

		return serialized.join(" ");
	}

	this.createTemplate = function() {
		var { data, template, componentId, styleId, parentTag } = this;
		var attributes = this.serializeAttributes(parentTag.attributes);
		var xml = `
			<${parentTag.name} styleid="${styleId}" id="${componentId}" ${attributes}>
				${Reflect.apply(template, this, [data])}
			</${parentTag.name}>
		`;

		return xml;
	}

	this.renderHTML = function() {
		var { targetElement, append } = this;
		var $targetElement = $(targetElement);
		var xml = this.createTemplate();

		if($targetElement.length) {
			if(append) {
				$targetElement.append(xml);
			} else {
				$targetElement.html(xml);
			}
		} else {
			console.error(`Error: targetElement does not exists.`);
		}

		return this;
	}

	this.registerMethods = function() {
		var { methods } = this;
		var methodsKeys = Object.keys(methods);
		var forbiddenKeys = Object.keys(this);
		var self = this;

		for(var i=0; i<methodsKeys.length; i++) {
			var key = methodsKeys[i];

			if(key in forbiddenKeys) {

			} else {
				self[key] = methods[key];
			}
		}

		return this;
	}

	this.extractEvents = function(xmlElement) {
		var eventNames = [
			'on-click',
			'on-dblclick',
			'on-focus',
			'on-blur',
			'on-keyup',
			'on-keydown',
			'on-change',
			'on-submit',
			'on-load',	
			'on-hover',		
		];
		var events = [];

		for(var i=0; i<eventNames.length; i++) {
			var name = eventNames[i];
			var value = xmlElement.getAttribute(name);

			if(value) {
				events.push({ name, value });
			}
		}

		return events;		
	}

	this.extractReferences = function() {
		// var xmlDoc = $.parseXML(this.createTemplate());
		var xmlDoc = $.parseHTML($.trim(this.createTemplate()));
		var xml = $(xmlDoc);
		var refElements = xml.find("[ref]");
		var references = {};

		for(var i=0; i<refElements.length; i++) {
			var xmlElement = new XmlElement(refElements[i]);
			var key = xmlElement.getAttribute('ref');

			references[`$${key}`] = {
				jQElement: $(`#${this.componentId} [ref="${key}"]`),
				events: this.extractEvents(xmlElement)
			};
		}

		return references;
	}

	this.$refs = function() {
		var extractedReferences = this.extractReferences();
		var keys = Object.keys(extractedReferences);
		var $refs = { $self: $(`#${this.componentId}`) };

		for(var i=0; i<keys.length; i++) {
			var key = keys[i];

			if(key !== '$self') {
				$refs[key] = extractedReferences[key].jQElement
			}
		}

		return $refs;
	} 

	this.registerEvent = function(jQElement, event) {
		var self = this;
		var eventFn = self.events[event.value];

		function createFunction(fn) {
			return function(e) {
				Reflect.apply(fn, self, [e]); 
			}
		}

		if(event.name == 'on-click') {
			jQElement.click(createFunction(eventFn));
		}		
		if(event.name == 'on-dblclick') {
			jQElement.dblclick(createFunction(eventFn));
		}		
		if(event.name == 'on-focus') {
			jQElement.focus(createFunction(eventFn));
		}		
		if(event.name == 'on-blur') {
			jQElement.blur(createFunction(eventFn));
		}		
		if(event.name == 'on-keyup') {
			jQElement.blur(createFunction(eventFn));
		}		
		if(event.name == 'on-kdydown') {
			jQElement.blur(createFunction(eventFn));
		}		
		if(event.name == 'on-change') {
			jQElement.change(createFunction(eventFn));
		}		
		if(event.name == 'on-submit') {
			jQElement.submit(createFunction(eventFn));
		}		
		if(event.name == 'on-load') {
			jQElement.load(createFunction(eventFn));
		}
		if(event.name == 'on-hover') {
			var fns = eventFn();

			jQElement.hover(
				createFunction(fns.handlerIn), 
				createFunction(fns.handlerOut)
			);
		}		
	}

	this.registerEvents = function() {
		var references = this.extractReferences();
		var keys = Object.keys(references);

		for(var i=0; i<keys.length; i++) {
			var key = keys[i];
			var { jQElement, events } = references[key];

			for(var _i=0; _i<events.length; _i++) {
				var event = events[_i];

				this.registerEvent(jQElement, event);
			}
		}

		return this;
	}

	this.render = function() {
		var self = this;

		this.registerLifeCycle()
			.beforeRender()
			.generateStyleId().then(function(id) {
				self.styleId = id;
				self.generateComponentId()
					.renderHTML()
					.renderStyle()
					.registerMethods()
					.registerEvents()
					.afterRender();
			});			
		
	}
}