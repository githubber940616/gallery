function XmlElement(element) {
	this.element = element;

	this.extractAttributes = function() {
		var attributes = {};
		var nodeMap = this.element.attributes;

		for(var i=0; i<nodeMap.length; i++) {
			var { nodeName, nodeValue } = nodeMap[i];
			
			attributes[nodeName] = nodeValue;
		}

		return attributes;
	}

	this.getAttribute = function(name) {
		var attributes = this.extractAttributes();

		return attributes[name];
	}
}