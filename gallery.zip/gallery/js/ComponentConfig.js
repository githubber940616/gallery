var ComponentConfig = {
	targetElement: document.getElementsByTagName('body')[0],
	data: {},
	parentTag: {
		name: 'div',
		attributes: {
			class: 'component'
		},
	},
	append: false,
	style: function() {
		var { styleId } = this;
		var style = `
			[styleid="${styleId}"] {
				border: 1px solid #eee;
				padding: 5px;
				margin: 0;
				text-align: center;
			}
			[styleid="${styleId}"] p {
				cursor: pointer;
			}
		`;

		return style;
	},
	template: function() {
		var xml = `
			<h1>New Component with id: ${this.componentId}</h1>
			<p ref="clickable" on-click="sayHello">Click me!</p>
		`;

		return xml;
	},
	events: {
		sayHello: function(e) {
			console.log(e);
			alert(`Hello there I am ${this.componentId}`);
		}
	},
	methods: {
		add: function(number1, number2) {
			return number1 + number2;
		}
	},
	lifeCycle: {
		beforeRender: function() {
			console.log(`Creating component...`);

			return this;
		},
		afterRender: function() {
			console.log(`Finished creating component: ${this.componentId}`);
		
			return this;
		},
	}
}