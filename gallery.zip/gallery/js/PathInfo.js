function PathInfo() {
	this.extractSlash = function(text) {
		var backSlash = /[/]/;
		var frontSlash = /[\\]/;
		var slashType = null;

		if(text.search(backSlash) + 1) {
			slashType = "/";
		}
		if(text.search(frontSlash) + 1) {
			slashType = "\\";
		}
		
		return slashType;
	}

	this.hasSlash = function(text) {
		var slash =  this.extractSlash(text);

		return slash != null;
	}

	this.removeFirst = function(splitter, text) {
		var splitted = text.split(splitter);
		splitted.shift();

		return splitted.join(splitter);
	}

	this.extractFirst = function(splitter, text) {
		var splitted = text.split(splitter);

		return splitted.shift();		
	}

	this.removeLast = function(splitter, text) {
		var splitted = text.split(splitter);
		splitted.pop();

		return splitted.join(splitter);
	}

	this.extractLast = function(splitter, text) {
		var splitted = text.split(splitter);

		return splitted.pop();		
	}

	this.hasColon = function(text) {
		return text.search(":") + 1;
	}

	this.extractDrive = function(path) {
		var drive = null;

		if(this.hasColon(path)) {
			drive = this.extractFirst(":", path);
			drive += ":";
		}

		return drive;
	}

	this.extractDirectory = function(path, excludeDrive = false) {
		var slash = this.extractSlash(path);
		var directory = null;

		if(slash != null) {
			directory = this.removeLast(slash, path);
			
			if(excludeDrive) {
				directory = this.removeFirst(":", directory);	
			}
		}

		return directory;
	}

	this.extractFileName = function(path) {
		var slash = this.extractSlash(path);
		var fileName = path;

		if(slash != null) {
			fileName = this.extractLast(slash, path);
		}

		return fileName;
	}

	this.extractName = function(path) {
		var fileName = this.extractFileName(path);
		var name = fileName;
		
		if(this.hasDot(fileName)) {
			name = this.removeLast(".", fileName);
		}

		return name;
	}

	this.hasDot = function(text) {
		var dot = /[.]/;

		return text.search(dot) + 1;
	}

	this.extractExtension = function(path) {
		var fileName = this.extractFileName(path);
		var extension = null;

		if(this.hasDot(fileName)) {
			extension = this.extractLast(".", fileName);
		}

		return extension;
	}

	this.extract = function(path, type) {
		var info = path;	

		switch(type) {
			case 'drive': 
				info = this.extractDrive(path); 
				
				break;
			case 'directory': 
				info = this.extractDirectory(path); 
				
				break;
			case 'filename': 
				info = this.extractFileName(path); 
				
				break;
			case 'name': 
				info = this.extractName(path); 
				
				break;
			case 'extension': 
				info = this.extractExtension(path); 
				
				break;
		}

		return info;
	}

}