function Screen() {
	this.enterFullScreenMode = function() {
		var page = document.documentElement;

		if(page.requestFullscreen) {
			page.requestFullscreen();
		}
		if(page.mozRequestFullScreen) {
			page.mozRequestFullScreen();
		}
		if(page.webkitRequestFullscreen) {
			page.webkitRequestFullscreen();
		}
		if(page.msRequestFullscreen) {
			page.msRequestFullscreen();
		}
	};

	this.exitFullScreenMode = function() {
		if(document.exitFullscreen) {
			document.exitFullscreen();
		}
		if(document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		}
		if(document.webkitExitFullscreen) {
			document.webkitExitFullscreen();
		}
		if(document.msExitFullscreen) {
			document.msExitFullscreen();
		}
	};
}