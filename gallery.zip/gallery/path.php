<?php
$root = './';
$path = array(
	'root'=> $root,
	'shared'=> $root . 'php/shared/',
	'exceptions'=> $root . 'php/shared/exceptions/',
	'albums'=> $root . 'Albums/'
);
?>