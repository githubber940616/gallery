var SlideShow = new SlideShowComponent({
	targetElement: document.getElementsByTagName('body')[0],
});
SlideShow.render();
var DirectoryModalCopying = new DirectoryModalComponent({
	folders,
	targetElement: document.getElementsByTagName('body')[0],
	header: { icon: 'copy', title: 'Copy to' },
	selectedQuery: `#container .image[selected] [ref="copyBtn"]`,
});
DirectoryModalCopying.render();
var DirectoryModalMoving = new DirectoryModalComponent({
	folders,
	targetElement: document.getElementsByTagName('body')[0],
	header: { icon: 'copy', title: 'Move to' },
	selectedQuery: `#container .image[selected] [ref="moveBtn"]`,
});
DirectoryModalMoving.render();
var ImagePreview = new ImagePreviewComponent({
	targetElement: document.getElementsByTagName('body')[0],
});
ImagePreview.render();

var Tools = {
	_,
	SlideShow,
	ImagePreview,
	DirectoryModalCopying,
	DirectoryModalMoving,
	PathInfo: new PathInfo(),
	Screen: new Screen(),
};

var selectorQuery = {
	selected: `#container .image:not([selected]) .image__icon`,
	unselected: `#container .image[selected] .image__icon`,
};
var navBar = new NavigationBarComponent({
	targetElement: document.getElementById('header'),
	buttons: [
		'add-photos',
		'play',
		'move',
		'copy',
		'delete-image',
		'folders',
	],
	folders,
	insideFolder: true,
	selectorQuery,
});
navBar.render();

if(images) {
	for(var i=0; i<images.length; i++) {
		var { name, src, folder } = images[i];
		var image = new ImageComponent({
			name,
			src, 
			folder,
			type: 'old',
			targetElement: document.getElementById('container'),
		});

		image.render();
	}	
}