<?php
$root = '../../';
$path = array(
	'root'=> $root,
	'shared'=> $root . 'php/shared/',
	'image'=> $root . 'php/shared/image/',
	'temp'=> $root . 'temp/',
	'exceptions'=> $root . 'php/shared/exceptions/',
	'albums'=> $root . 'Albums/'
);
?>