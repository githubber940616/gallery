<?php
require_once('path.php');

require_once($path['shared'] . 'set-timezone.php');	
require_once($path['shared'] . 'JSONResponse.php');	
require_once($path['shared'] . 'FileManager.php');	

try {
	$directory = $path['root'] . $_REQUEST['directory'];
	$action = $_REQUEST['action'];
	$oldName = $_REQUEST['old_name'];
	$newName = $_REQUEST['new_name'];

	$fileManager = new FileManager($directory);
	$message = 'Success.';

	switch($action) {
		case 'create-folder' : 
			$fileManager->createFolder($newName);
			$message = 'Successfully created the folder ' . $newName . '.';
			$data = array('name'=> $newName);

			break;
		case 'delete-folder' : 
			$fileManager->deleteFolder($oldName);
			$message = 'Successfully deleted the folder ' . $oldName . '.';

			break;
		case 'rename-folder' : 
			$fileManager->renameFolder($oldName, $newName);
			$message = 'Successfully renamed the folder ' . $oldName . ' to ' . $newName . '.';
			$data = array('name'=> $newName);

			break;
		case 'get-files' : 
			$data = $fileManager->getFiles();

			break;
		case 'get-folders' : 
			$data = $fileManager->getFolders();

			break;
		case 'get-contents' : 
			$data = $fileManager->getContents();

			break;
	}

	$response = new JSONResponse('success', $message, $data);
	$response->out();
} catch(Exception $e) {
	$response = new JSONResponse('error', $e->getMessage());
	$response->out();
}
?>