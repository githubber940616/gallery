<?php
require_once('path.php');

require_once($path['shared'] . 'set-timezone.php');	
require_once($path['shared'] . 'JSONResponse.php');	
require_once($path['shared'] . 'FileManager.php');	

try {
	$directory = $path['root'] 
		. $_REQUEST['directory'] 
		. '/' 
		. $_REQUEST['folder'];

	$action = $_REQUEST['action'];
	$oldName = $_REQUEST['old_name'];
	$newName = $_REQUEST['new_name'];
	$destFolder = $_REQUEST['dest_folder'];
	$srcFolder = $_REQUEST['folder'];

	$fileManager = new FileManager($directory);
	$message = 'Success.';

	switch($action) {
		case 'get-all-image' : 
			$filterIn = array('png', 'jpg', 'bmp');
			$data = $fileManager->getFiles($filterIn);

			break;
		case 'upload-image' : 
			require_once($path['shared'] . 'SlideShowSettings.php');	
			require_once($path['shared'] . 'TemporaryImageMaker.php');
			require_once($path['shared'] . 'Image.php');
			require_once($path['shared'] . 'AjaxImageUploader.php');
			require_once($path['shared'] . 'ImageUploader.php');
			require_once($path['shared'] . 'ImageUploaderFactory.php');

			SlideShowSettings::setConfig($path['root'] . 'settings.json');
			ImageUploaderFactory::setBaseDir($directory);

			$settings = SlideShowSettings::getSettings();
			$tempImage = new TemporaryImageMaker($path['root'] . 'temp', $_POST['image_data']);

			$files = array(
				'name'=> $_POST['old_name'],
				'tmp_name'=> $tempImage->generate(),
				'ajax'=> true
			);	
			try {
				$image = new Image($files, $settings->image);
				$image->validate();
				$imageUploader = ImageUploaderFactory::createUploader($image);
				$imageUploader->upload();
				$message = 'Successfully uploaded the image ' . $oldName . '.';
				$data = array('name'=> $oldName);
			} catch(Exception $e) {
				if(file_exists($image->file['tmp_name'])) {
					unlink($image->file['tmp_name']);
				}

				throw $e;				
			}

			break;
		case 'delete-image' : 
			$fileManager->deleteFile($oldName);
			$message = 'Successfully deleted the image ' . $oldName . '.';

			break;
		case 'rename-image' : 
			$fileManager->renameFile($oldName, $newName);
			$message = 'Successfully renamed the image ' . $oldName . ' to ' . $newName . '.';
			$data = array('name'=> $newName);

			break;
		case 'copy-image' : 
			$srcPath = $srcFolder.'/'.$oldName;
			$destPath = $destFolder.'/'.$oldName;
			$fileCopyManager = new FileManager($path['root'] . $_REQUEST['directory']);
			$fileCopyManager->copyFile($srcPath, $destPath);
			$message = 'Successfully copied the image ' . $oldName . ' to ' . $destFolder . ' folder.';

			break;
		case 'move-image' : 
			$srcPath = $srcFolder.'/'.$oldName;
			$destPath = $destFolder.'/'.$oldName;
			$fileMoveManager = new FileManager($path['root'] . $_REQUEST['directory']);
			$fileMoveManager->moveFile($srcPath, $destPath);
			$message = 'Successfully moved the image ' . $oldName . ' to ' . $destFolder . ' folder.';

			break;
	}

	$response = new JSONResponse('success', $message, $data);
	$response->out();
} catch(Exception $e) {
	$response = new JSONResponse('error', $e->getMessage(), $data);
	$response->out();
}
?>