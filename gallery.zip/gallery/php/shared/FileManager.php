<?php
require_once('exceptions/FolderNameInvalidException.php');
require_once('exceptions/FolderNotEmptyException.php');
require_once('exceptions/FolderAlreadyExistsException.php');
require_once('exceptions/FileNotExistsException.php');
require_once('exceptions/FileNotCopiedException.php');
require_once('exceptions/FileNameInvalidException.php');
require_once('exceptions/FileAlreadyExistsException.php');
require_once('exceptions/FileNotRenamedException.php');
require_once('exceptions/FileNotDeletedException.php');

class FileManager {
	public $directory;

	public function __construct($directory) {
		$this->directory = $directory;
	}

	public function isNameValid($name) {
		if(preg_match("/^[a-zA-Z0-9._-\s]{1,50}$/", $name)) {
			return true;
		}

		return false;
	}

	public function getFolders() {
		$filterOut = array('.', '..');
		$unfileredFiles = scandir($this->directory);

		foreach ($unfileredFiles as $file) {
			$fileName = $this->directory . "/" . $file;

			if(is_dir($fileName) && !in_array($file, $filterOut)) {
				$folders[] = $file;
			}
		}

		return $folders;
	}

	public function createFolder($name) {
		if(!$this->isNameValid($name)) {
			throw new FolderNameInvalidException('Folder name is not valid.');
		}

		$folder = $this->directory . "/" . $name;

		if (!is_dir($folder)) {
		    mkdir($folder);
		} else {
			throw new FolderAlreadyExistsException('Folder already exists.');
		}
	}

	public function getContents() {
		$files = $this->getFiles();
		$files = (is_array($files)) ? $files : array();
		$folders = $this->getFolders();
		$folders = (is_array($folders)) ? $folders : array();

		return array_merge($files, $folders);
	}

	public function deleteFolder($name) {
		$folder = $this->directory . "/" . $name;
		$fileManager = new FileManager($folder);
		$contents = $fileManager->getContents();

		if(count($contents) > 0) {
			throw new FolderNotEmptyException('Folder is not empty.');
		} else {
			rmdir($folder);
		}
	}

	public function renameFolder($oldName, $newName) {
		if(!$this->isNameValid($newName)) {
			throw new FolderNameInvalidException('Folder name is not valid.');
		}

		$oldFolder = $this->directory . "/" . $oldName;
		$newFolder = $this->directory . "/" . $newName;

		if(!is_dir($oldFolder)) {
			throw new FolderNotExistsException('Folder does not exists.');			
		}
		if (!is_dir($newFolder)) {
			rename($oldFolder, $newFolder);
		} else {
			throw new FolderAlreadyExistsException('Folder already exists.');
		}
	}

	public function getFiles($filterIn = NULL) {
		$unfileredFiles = scandir($this->directory);

		foreach ($unfileredFiles as $file) {
			$fileName = $this->directory . "/" . $file;

			if(!is_dir($fileName)) {
				if($filterIn) {
					if(in_array($this->extractExtension($file), $filterIn)) {
						$filteredFiles[] = $file;
					}					
				} else {
					$filteredFiles[] = $file;
				}
			}
		}

		return $filteredFiles;
	}

	public function extractExtension($file) {
		return strtolower(pathinfo($file, PATHINFO_EXTENSION));
	}

	public function deleteFile($file) {
		$filePath = $this->directory . "/" . $file;

		if(!unlink($filePath)) {
			throw new FileNotDeletedException('File not deleted.');
		}

		return TRUE;
	}

	public function checkIfExists($file) {
		$filePath = $this->directory . "/" . $file;

		return file_exists($filePath);
	}

	public function renameFile($oldName, $newName) {
		if(!$this->isNameValid($newName)) {
			throw new FileNameInvalidException('File name is not valid.');
		}
		if($this->checkIfExists($newName)) {
			throw new FileAlreadyExistsException('File already exists.');
		}
		if(!rename($this->directory.'/'.$oldName, $this->directory.'/'.$newName)) {
			throw new FileNotRenamedException('File not renamed.');
		}

		return TRUE;
	}

	public function copyFile($srcPath, $destPath) {
		if(!$this->checkIfExists($srcPath)) {
			throw new FileNotExistsException('File does not exists.');
		}
		if($this->checkIfExists($destPath)) {
			throw new FileAlreadyExistsException('File already exists.');
		}
		if (!copy($this->directory.'/'.$srcPath, $this->directory.'/'.$destPath)) {
			throw new FileNotCopiedException('File was not copied');
		}

		return true;
	}

	public function moveFile($srcPath, $destPath) {
		if(!$this->checkIfExists($srcPath)) {
			throw new FileNotExistsException('File does not exists.');
		}
		if($this->checkIfExists($destPath)) {
			throw new FileAlreadyExistsException('File already exists.');
		}
		if (!rename($this->directory.'/'.$srcPath, $this->directory.'/'.$destPath)) {
			throw new FileNotMovedException('File was not moved');
		}

		return true;
	}
}

?>