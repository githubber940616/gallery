<?php
class FileNotSavedException extends Exception {}
?>