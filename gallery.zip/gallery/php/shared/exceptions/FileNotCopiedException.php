<?php
class FileNotCopiedException extends Exception {}
?>