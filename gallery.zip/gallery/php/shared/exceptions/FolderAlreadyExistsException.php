<?php
class FolderAlreadyExistsException extends Exception {}
?>