<?php
class FileNotEmptyException extends Exception {}
?>