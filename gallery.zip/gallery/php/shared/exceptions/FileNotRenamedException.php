<?php
class FileNotRenamedException extends Exception {}
?>