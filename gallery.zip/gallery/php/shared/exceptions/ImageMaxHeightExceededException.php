<?php
class ImageMaxHeightExceededException extends Exception {}
?>