<?php
class FileNotReadException extends Exception {}
?>