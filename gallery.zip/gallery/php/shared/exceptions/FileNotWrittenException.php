<?php
class FileNotWrittenException extends Exception {}
?>