<?php
class FileEmptyException extends Exception {}
?>