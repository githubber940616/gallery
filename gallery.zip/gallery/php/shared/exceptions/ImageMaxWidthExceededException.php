<?php
class ImageMaxWidthExceededException extends Exception {}
?>