<?php
class FolderNotEmptyException extends Exception {}
?>