<?php
class FileAlreadyExistsException extends Exception {}
?>