<?php
class ImageMinWidthNotReachedException extends Exception {}
?>