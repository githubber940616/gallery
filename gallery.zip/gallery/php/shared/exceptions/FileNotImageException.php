<?php
class FileNotImageException extends Exception {}
?>