<?php
class FolderNameInvalidException extends Exception {}
?>