<?php
class FileNameInvalidException extends Exception {}
?>