<?php
class ImageMinHeightNotReachedException extends Exception {}
?>