<?php
class FolderNotExistsException extends Exception {}
?>