<?php
class FileNotDeletedException extends Exception {}
?>