<?php
class FileNotExistsException extends Exception {}
?>