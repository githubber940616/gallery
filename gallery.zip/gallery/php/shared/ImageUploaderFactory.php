<?php
require_once('Image.php');
require_once('ImageUploader.php');
require_once('AjaxImageUploader.php');

class ImageUploaderFactory {
	public static $baseDir = 'uploads';

	public static function setBaseDir($dir) {
		self::$baseDir = $dir;
	}	

	public static function createUploader($image) {
		if($image->file['ajax']) {
			$uploader = new AjaxImageUploader(self::$baseDir, $image);
		} else {
			$uploader = new ImageUploader(self::$baseDir, $image);
		} 

		return $uploader;
	}
}

?>