<?php
require_once('exceptions/FileNotReadException.php');
require_once('exceptions/FileNotWrittenException.php');
require_once('exceptions/FileNotDeletedException.php');

require_once('ImageUploader.php');

class AjaxImageUploader extends ImageUploader {
	public function __construct($baseDir, $image) {
		parent::__construct($baseDir, $image);
	}

	public function saveImage() {
		$contents = file_get_contents($this->image->file['tmp_name']);
		if(!$contents) {
			throw new FileNotReadException('Temporary file was not read.');
		}
		if(!file_put_contents($this->uploadPath, $contents)) {
			throw new FileNotWrittenException('New file was not written.');
		}
		if(!unlink($this->image->file['tmp_name'])) {
			throw new FileNotDeletedException('Temporary file was not deleted.');
		}

		return $this;
	}
}
?>