<?php
class TemporaryImageMaker {
	public $data;
	public $tempFile;

	public function __construct($tempDir, $fileData) {
		$data = explode('base64,', $fileData);
		$data = $data[1];
		$this->data = $data;
		$this->tempFile = tempnam($tempDir, 'img');
	}

	public function generate() {
		$this->createImage();

		return $this->tempFile;
	}

	public function createImage() {
		$imageData = base64_decode($this->data);
		$image = imagecreatefromstring($imageData);

		imagepng($image, $this->tempFile, 0);
		imagedestroy($image);
	}
}
?>