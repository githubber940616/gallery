<?php
require_once('exceptions/FileEmptyException.php');
require_once('exceptions/FileNotImageException.php');
require_once('exceptions/ImageMinWidthNotReachedException.php');
require_once('exceptions/ImageMinHeightNotReachedException.php');
require_once('exceptions/ImageMaxWidthExceededException.php');
require_once('exceptions/ImageMaxHeightExceededException.php');

class Image {
	public $file;
	public $settings;
	public $properties;

	public function __construct($file, $settings) {
		$this->file = $file;
		$this->settings = $settings;
	}

	public function getProperties() {
		return $this->properties;
	}

	public function getFileExtension() {
		return pathinfo($this->file['name'], PATHINFO_EXTENSION);
	}

	public function getFileSize() {
		$fileInfo = new SplFileInfo($this->file['tmp_name']);

		return $fileInfo->getSize();
	}

	public function setProperties() {
		$rawProperties = getimagesize($this->file['tmp_name']);
		$properties = array(
			'name'=> $this->file['name'],
			'extension'=> $this->getFileExtension(),
			'width'=> $rawProperties[0],
			'height'=> $rawProperties[1],
			'size'=> $this->getFileSize(),
			'type'=> strtolower($rawProperties['mime']),
		);

		$this->properties = $properties;

		return $this;
	}

	public function checkIfTypeWasImage() {
		$type = explode("/", $this->properties['type']);
		
		if($type[0] != "image") {
			throw new FileNotImageException("File type is not an image.");
		}

		return $this;
	}

	public function checkIfFileWasNotEmpty() {
		if($this->properties['size'] <= 0) {
			throw new FileEmptyException("File is empty.");
		}

		return $this;
	}

	public function checkIfMinWidthWasReached() {
		if($this->properties['width'] < $this->settings->{'min-width'}) {
			throw new ImageMinWidthNotReachedException("Image did not reached the minimum width of ". $this->settings->{'min-width'} .".");
		}

		return $this;
	}

	public function checkIfMinHeightWasReached() {
		if($this->properties['height'] < $this->settings->{'min-height'}) {
			throw new ImageMinHeightNotReachedException("Image did not reached the minimum height of ". $this->settings->{'min-height'} .".");
		}

		return $this;
	}

	public function checkIfMaxWidthWasNotExceeded() {
		if($this->properties['width'] > $this->settings->{'max-width'}) {
			throw new ImageMaxWidthExceededException("Image exceeded the maximum width of ". $this->settings->{'max-width'} .".");
		}

		return $this;
	}

	public function checkIfMaxHeightWasNotExceeded() {
		if($this->properties['height'] > $this->settings->{'max-height'}) {
			throw new ImageMaxHeightExceededException("Image exceeded the maximum height of ". $this->settings->{'max-height'} .".");
		}

		return $this;
	}

	public function validate() {
		$this->setProperties()
			->checkIfTypeWasImage()
			->checkIfFileWasNotEmpty()
			->checkIfMinWidthWasReached()
			->checkIfMinHeightWasReached()
			->checkIfMaxWidthWasNotExceeded()
			->checkIfMaxHeightWasNotExceeded();

		return $this;
	}
}

?>