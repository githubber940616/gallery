<?php
require_once('exceptions/FileNotSavedException.php');
require_once('exceptions/FileAlreadyExistsException.php');

class ImageUploader {
	protected $baseDir;
	protected $uploadPath;
	protected $image;

	public function __construct($baseDir, $image) {
		$this->baseDir = $baseDir;
		$this->image = $image;
	}

	public function generateFileName() {
		$fileName = "img".$currentDateTime.".".$this->image->getFileExtension();

		return $fileName;		
	}

	public function setUploadPath() {
		$currentDateTime = date("YmdHis");
		$fileName = $this->image->properties['name'];
		$filePath = implode("/", array($this->baseDir, $fileName));

		$this->uploadPath = $filePath;

		return $this;	
	}

	public function checkIfFileExists() {
		if(file_exists($this->uploadPath)) {
			throw new FileAlreadyExistsException('File already exists.');
		}	

		return $this;	
	}

	public function saveImage() {
		if(!move_uploaded_file($this->image->file['tmp_name'], $this->uploadPath)) {
			throw new FileNotSavedException("File not saved.");
		}

		return $this;
	}

	public function upload() {
		$this->setUploadPath()
			->checkIfFileExists()
			->saveImage();
	}
}