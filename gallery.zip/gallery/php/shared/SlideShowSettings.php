<?php
class SlideShowSettings {
	private static $settings;
	private static $configFile;

	public static function getSettings() {
		if(!self::$settings) {
			self::$settings = self::readSettings();
		}

		return self::$settings;
	}

	public static function readSettings() {
		return json_decode(file_get_contents(self::$configFile));
	}

	public static function setConfig($file) {
		self::$configFile = $file;
	}
}

?>