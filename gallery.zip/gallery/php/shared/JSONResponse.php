<?php
class JSONResponse {
	public $status;
	public $message;
	public $data;

	public function __construct($status='success', $message='', $data='') {
		$this->status = $status;
		$this->message = $message;
		$this->data = $data;
	}

	public function out() {
		$response = array(
			'status'=> $this->status,
			'message'=> $this->message,
			'data'=> $this->data
		);
		
		echo json_encode($response);		
	}
}

?>