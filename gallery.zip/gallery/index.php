<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gallery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="vendor/bootstrap-3.3.5-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="vendor/bootstrap-3.3.5-dist/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/rotate.css">
<link rel="stylesheet" href="css/tooltip-theme.css">
<link rel="icon" href="icon.png">
</head>
<body>
<style>
	#container {
		padding: 70px 0;
	}
</style>
<div id="header" class="container"></div>
<div id="container" class="container"></div>
<div id="footer"></div>
<script src="vendor/lodash/lodash.min.js"></script>
<script src="vendor/jquery-3.3.1/jquery.min.js"></script>
<script src="vendor/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
<script src="js/Screen.js"></script>
<script src="js/Hasher.js"></script>
<script src="js/XmlElement.js"></script>
<script src="js/ComponentConfig.js"></script>
<script src="js/ComponentConfigFixer.js"></script>
<script src="js/Component.js"></script>
<script src="js/components/NavigationBarComponent.js"></script>
<script src="js/components/FooterBarComponent.js"></script>
<script src="js/components/StatusMixin.js"></script>
<script src="js/components/FolderComponent.js"></script>
<script>
var folders = <?php 
	require_once('path.php');
	require_once($path['shared'] . 'FileManager.php');

	$fileManager = new FileManager($path['root'] . 'Albums');
	
	echo json_encode($fileManager->getFolders());
?>;

</script>
<script src="index.js"></script>
</body>
</html>