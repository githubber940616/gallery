var CURRENT_FOLDER;
var Tools = {
	_,
	Screen: new Screen(),
};

var selectorQuery = {
	selected: `#container .folder:not([selected]) .folder__icon`,
	unselected: `#container .folder[selected] .folder__icon`,
};
var navBar = new NavigationBarComponent({
	targetElement: document.getElementById('header'),
	buttons: [
		'create-folder',
		'delete-folder',
	],
	folders,
	insideFolder: false,
	selectorQuery,
});
navBar.render();

if(folders) {
	for(var i=0; i<folders.length; i++) {
		var folder = new FolderComponent({
			name: folders[i],
			type: 'old',
			targetElement: document.getElementById('container'),
		});

		folder.render();
	}	
}
