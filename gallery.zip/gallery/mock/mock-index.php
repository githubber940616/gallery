<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gallery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../vendor/bootstrap-3.3.5-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../vendor/bootstrap-3.3.5-dist/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="../css/rotate.css">
<link rel="stylesheet" href="../css/tooltip-theme.css">
</head>
<body>
<style>
	body {
		padding-top: 65px;
	}
</style>
<div id="header" class="container">
	<?php 
		$page = 'index';
		include_once('templates/navigation-bar.php'); 
	?>
</div>
<div id="container" class="container">
	<div class="row">
		<div class="col-sm-12">
			<?php 
				include_once('mock-index-helper.php'); 	
				
				$status='processing';
				
				include('templates/folder.php'); 

				$status='success';
				
				include('templates/folder.php'); 

				$status='error';
				
				include('templates/folder.php'); 
				
				$status='check';

				include('templates/folder.php'); 	

				$status='unchecked';
				
				include('templates/folder.php'); 

				$status=NULL;
				$rename=TRUE;

				include('templates/folder.php'); 

				$rename=FALSE;

				include('templates/folder.php'); 	
				include('templates/folder.php'); 

			?>	
		</div>
	</div>
</div>
<div id="footer">
<?php
	include_once('templates/footer-bar.php'); 	
?>
</div>
<script src="../vendor/lodash/lodash.min.js"></script>
<script src="../vendor/jquery-3.3.1/jquery.min.js"></script>
<script src="../vendor/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
</body>
</html>
