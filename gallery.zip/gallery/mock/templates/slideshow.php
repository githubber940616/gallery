<style>
.slideshow-container {
    display: none;
    min-width: 800px;
    min-height: 600px;
    width: 100%;
    height: 100%;
    position: fixed;
    z-index: 30;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
}
.slideshow-container .btn {
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 31;
    display: block;
    background: none;
    color: #fff;
}
.slideshow-container .item img {
    height: 100%;
    width: 100%;
}
</style>
<div class="slideshow-container">
    <button class="btn btn-default btn-lg" 
        onclick="$(`.slideshow-container`).hide()">
        <span class="glyphicon glyphicon-remove"></span>
    </button>
    <div id="slideshow" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#slideshow" data-slide-to="0" class="active"></li>
            <li data-target="#slideshow" data-slide-to="1"></li>
            <li data-target="#slideshow" data-slide-to="2"></li>
            <li data-target="#slideshow" data-slide-to="3"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="assets/Blue hills.jpg" />
                <div class="carousel-caption">
                    <h3>Blue hills.jpg</h3>
                </div>
            </div>

            <div class="item">
                <img src="assets/Sunset.jpg" />
                <div class="carousel-caption">
                    <h3>Sunset.jpg</h3>
                </div>
            </div>

            <div class="item">
                <img src="assets/Water lilies.jpg" />
                <div class="carousel-caption">
                    <h3>Water lilies.jpg</h3>
                </div>
            </div>

            <div class="item">
                <img src="assets/Winter.jpg" />
                <div class="carousel-caption">
                    <h3>Winter.jpg</h3>
                </div>
            </div>
        </div>
        <a class="left carousel-control" href="#slideshow" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#slideshow" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>