<style>
.image {
	margin: 10px 5px;
	height: 140px;
	width: 140px;
	float: left;
	text-align: center;
	position: relative;
}
.image__icon {
	cursor: pointer;
	color: #ffdb2b;
	height: 105px;
	max-width: 93.33px;
	margin: 0 auto;
	overflow: hidden;
}
.image__icon--uploading img {
	opacity: 0.3;
}
.image__icon img {
	margin-top: 25px;
	height: 70px;
}
.image:hover .image__icon {
	text-shadow: 1px 1px 2px #999;	
	color: #ffec3c;
}
.image__name {
	font-size: 14px;
	font-weight: normal;
	cursor: pointer;	
}
.image__name:hover {
	color: #333;
}
.image__name .image__text-box {
	display: none;	
}
.image__name .image__text-box input[type="text"] {
	width: 80px;
	text-align: center;
}
.image__name--rename label {
	display: none;
}
.image__name--rename .image__text-box {
	display: inline;
}
.image__status {
	position: absolute;
    top: 75px;
    right: 15px;
	font-size: 20px;
	cursor: pointer;
}
.image__status--check,
.image__status--unchecked,
.image__status--processing,
.image__status--error,
.image__status--success {
	background-color: rgba(255, 255, 255, 0.9);
	border-radius: 1px;
	border: 1px solid #ddd;
	padding: 1px;
}
.image__status .glyphicon {
	display: none;
}
.image__status--check .glyphicon-check {
	color: #337ab7;	
	display: block;
}
.image__status--unchecked .glyphicon-unchecked {
	color: #555;	
	display: block;
}
.image__status--processing .glyphicon-repeat {
	color: #31708f;
	display: block;
}
.image__status--error .glyphicon-exclamation-sign {
	color: #a94442;
	display: block;
}
.image__status--success .glyphicon-ok-sign {
	color: #3c763d;
	display: block;
}

</style>
<div class="image<?php echo ($status) ? " " . $tooltipData[$status]['color'] : "" ?>" 
	<?php echo ($status) ? setToolTip($tooltipData[$status]) : "" ?>>
	<div class="image__icon<?php echo ($uploading) ? " image__icon--uploading" : "" ?>">
		<img src="<?php echo $imageSrc; ?>" 
		onclick="$(`.image-view`).show();"/>
	</div>
	<div class="image__name<?php echo ($rename) ? " image__name--rename" : "" ?>">
		<label>New Image.png</label>
		<span class="image__text-box">
			<input type="text" value="New Image" name="image_name" />
			.png
		</span>
	</div>
	<div class="image__status<?php echo ($status) ? " image__status--".$status : "" ?>">
		<span class="glyphicon glyphicon-check"></span>
		<span class="glyphicon glyphicon-unchecked"></span>
		<span class="glyphicon glyphicon-repeat rotate"></span>
		<span class="glyphicon glyphicon-ok-sign"></span>
		<span class="glyphicon glyphicon-exclamation-sign"></span>
	</div>
</div>