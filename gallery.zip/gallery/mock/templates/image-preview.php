<style>
.image-preview {
	position: fixed;
	width: 100%;
	height: 100%;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	display: none;
	z-index: 20;
}
.image-preview__background {
	width: 100%;
	height: 100%;
	background-color: rgba(0, 0, 0, 0.5);
	margin: 0;
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
}
.image-preview__modal {
	width: 520px;
	height: 520px;
	background-color: #fff;
	border: 1px solid #ddd;
	margin: 0 auto;
	margin-top: 70px;
	border-radius: 5px;
}
.image-preview__modal__header {
	text-align: center;
}
.image-preview__modal__body {
	padding: 10px;
}
.image-preview__modal__footer {
	padding: 10px;
	text-align: right;
}
.image-preview__image {
	max-width: 500px;
	border: 1px solid #eee;
	overflow: hidden;
}
.image-preview__image img {
	height: 375px;
}
</style>
<div class="image-preview">
	<div class="image-preview__background">
		<div class="image-preview__modal">
			<div class="image-preview__modal__header">
				<h3>Sunset.jpg</h3>
			</div>
			<div class="image-preview__modal__body">
				<div class="image-preview__image">
					<img src="assets/Sunset.jpg" />
				</div>
			</div>
			<div class="image-preview__modal__footer">
				<button class="btn btn-default"
					onclick="$(`.image-preview`).hide();">
					<span class="glyphicon glyphicon-remove"></span>
					Close
				</button>
			</div>			
		</div>
	</div>
</div>