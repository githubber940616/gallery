<style>
.folder {
	margin: 10px 5px;
	height: 140px;
	width: 140px;
	float: left;
	text-align: center;
	position: relative;
}

.folder__icon {
	font-size: 70px;
	cursor: pointer;
	color: #ffdb2b;
	height: 105px;
}
.folder__icon .glyphicon {
	margin-top: 25px;
}
.folder:hover .folder__icon {
	text-shadow: 1px 1px 2px #999;	
	color: #ffec3c;
}
.folder__name {
	font-size: 14px;
	font-weight: normal;
	cursor: pointer;	
}
.folder__name:hover {
	color: #333;
}
.folder__name input[type=text] {
	width: 100px;
	text-align: center;
	display: none;
}
.folder__name--rename label {
	display: none;
}
.folder__name--rename input[type="text"] {
	display: inline;
}
.folder__status {
	position: absolute;
    top: 75px;
    right: 15px;
	font-size: 20px;
	cursor: pointer;
}
.folder__status--check,
.folder__status--unchecked,
.folder__status--processing,
.folder__status--error,
.folder__status--success {
	background-color: rgba(255, 255, 255, 0.9);
	border-radius: 1px;
	border: 1px solid #ddd;
	padding: 1px;
}
.folder__status .glyphicon {
	display: none;
}
.folder__status--check .glyphicon-check {
	color: #337ab7;	
	display: block;
}
.folder__status--unchecked .glyphicon-unchecked {
	color: #555;	
	display: block;
}
.folder__status--processing .glyphicon-repeat {
	color: #31708f;
	display: block;
}
.folder__status--error .glyphicon-exclamation-sign {
	color: #a94442;
	display: block;
}
.folder__status--success .glyphicon-ok-sign {
	color: #3c763d;
	display: block;
}

</style>
<div class="folder<?php echo ($status) ? " " . $tooltipData[$status]['color'] : "" ?>" 
	<?php echo ($status) ? setToolTip($tooltipData[$status]) : "" ?>>
	<div class="folder__icon">
		<span class="glyphicon glyphicon-folder-open"></span>
	</div>
	<div class="folder__name<?php echo ($rename) ? " folder__name--rename" : "" ?>">
		<label>New Folder</label>
		<input type="text" value="New Folder" name="folder_name" />
	</div>
	<div class="folder__status<?php echo ($status) ? " folder__status--".$status : "" ?>">
		<span class="glyphicon glyphicon-check"></span>
		<span class="glyphicon glyphicon-unchecked"></span>
		<span class="glyphicon glyphicon-repeat rotate"></span>
		<span class="glyphicon glyphicon-ok-sign"></span>
		<span class="glyphicon glyphicon-exclamation-sign"></span>
	</div>
</div>