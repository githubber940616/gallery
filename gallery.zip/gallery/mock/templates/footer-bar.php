<style>
.footer-bar {
	height: 60px;
	background-color: #fff;
	border-bottom: 1px solid #ddd;
	box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	margin: 0;
	z-index: 10;
}
.footer-bar__box {
	max-width: 1170px;
	width: 100%;
	height: 100%;
	position: relative;
	margin: 0 auto;
	text-align: center;
}
.footer-bar__buttons {
	padding: 10px;
}
</style>
<div class="footer-bar">
	<div class="footer-bar__box">
		<div class="footer-bar__buttons">
			<button class="btn btn-default">
				<span class="glyphicon glyphicon-check"></span>
				Select All
			</button>
			<button class="btn btn-default">
				<span class="glyphicon glyphicon-unchecked"></span>
				Unselect All
			</button>
		</div>
	</div>
</div>