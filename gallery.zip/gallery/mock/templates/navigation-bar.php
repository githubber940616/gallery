<style>
.navigation-bar {
	height: 60px;
	background-color: #fff;
	border-bottom: 1px solid #ddd;
	box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	margin: 0;
	z-index: 10;
}
.navigation-bar__box {
	max-width: 1170px;
	width: 100%;
	height: 100%;
	position: relative;
	margin: 0 auto;
}
.navigation-bar__logo {
	float: left;
	height: 100%;
	padding: 10px 20px;
}
.navigation-bar__logo a {
	text-decoration: none;
	color: #555;
}
.navigation-bar__logo a:hover {
	color: #999;
}
.navigation-bar__logo a:hover span {
	border-color: #999;
	box-shadow: 0 1px 10px 1px rgba(0, 0, 0, 0.2);
}
.navigation-bar__logo span, 
.navigation-bar__logo h2 {
	vertical-align: baseline;
	padding: 0;
	margin: 0;
} 	
.navigation-bar__logo span {
	border: 2px solid #555;
	padding: 1px;
}
.navigation-bar__icons {
	float: right;
	position: relative;
	height: 100%;
	padding: 0 5px;
}
.navigation-bar__icon {
	font-size: 20px;
	height: 100%;
	padding: 10px 5px;
	display: inline-block;
	text-align: center;
	color: #555;
}
.navigation-bar__icon:hover {
	color: #999;
}
.navigation-bar__icon span {
	vertical-align: middle;
}
</style>
<div class="navigation-bar">
	<div class="navigation-bar__box">
		<div class="navigation-bar__logo">
			<a href="#">
				<h2>
					<span class="glyphicon glyphicon-picture"></span>
					Gallery
				</h2>
			</a>
		</div>
		<div class="navigation-bar__icons">
			<a title="Mark / Select" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-unchecked"></span>
			</a>
			<?php if($page=='index') { ?>
			<a title="Create New Folder" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-folder-open"></span>
			</a>
			<?php } ?>
			<?php if($page=='album') { ?>
			<a title="Add New Photos" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-picture"></span>
			</a>
			<a title="Play" class="navigation-bar__icon" href="#"
				onclick="$(`.slideshow-container`).show()">
				<span class="glyphicon glyphicon-play"></span>
			</a>
			<a title="Move" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-move"></span>
			</a>
			<a title="Copy" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-copy"></span>
			</a>
			<?php } ?>
			<a title="Delete" class="navigation-bar__icon" href="#">
				<span class="glyphicon glyphicon-trash"></span>
			</a>
		</div>
	</div>
</div>