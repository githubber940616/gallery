<style>
.create-new-folder {
	margin: 10px 5px;
	padding: 0;
	width: 140px;
	text-align: center;
	cursor: pointer;
	color: #5eba5f;
	float: left;
	padding: 10px 5px;
}
.create-new-folder__box {
	position: relative;
	height: 120px;
	border: 5px solid #5eba5f;
	border-bottom-width: 25px;
	border-radius: 5px;
}
.create-new-folder__icon {
	position: absolute;
	top: 15px;
	left: 0;
	right: 0;
	font-size: 50px;
}
.create-new-folder__label {
	position: absolute;
	left: 0;
	right: 0;
	bottom: 0;	
	font-size: 13px;
}
.create-new-folder:hover {
	color: #5ecb5f;
}
.create-new-folder:hover .create-new-folder__box {
	border-color: #5ecb5f;
	box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),
		0 3px 10px 0 rgba(0,0,0,0.19);
}
.create-new-folder:hover .create-new-folder__label {
	/*text-shadow: 1px 1px 2px #999;	*/
}
.create-new-folder:hover .create-new-folder__icon {
	text-shadow: 1px 1px 2px #999;	
}
</style>
<div class="create-new-folder">
	<div class="create-new-folder__box">
		<span class="create-new-folder__icon glyphicon glyphicon-plus"></span>
		<label class="create-new-folder__label">Add Folder</label>
	</div>
</div>