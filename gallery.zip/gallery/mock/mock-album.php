<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gallery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../vendor/bootstrap-3.3.5-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="../vendor/bootstrap-3.3.5-dist/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="../css/rotate.css">
<link rel="stylesheet" href="../css/tooltip-theme.css">
</head>
<body>
<style>
	body {
		padding-top: 65px;
	}
</style>
<div id="header" class="container">
	<?php 
	$page = 'album';
	include_once('templates/navigation-bar.php'); 
	?>
</div>
<div id="container" class="container">
	<div class="row">
		<div class="col-sm-12">
			<?php 
				include_once('mock-album-helper.php'); 	
				
				$status='processing';
				$imageSrc='assets/Blue Hills.jpg';

				include('templates/image.php'); 

				$status='processing';
				$uploading=TRUE;
				$imageSrc='assets/Blue Hills.jpg';

				include('templates/image.php'); 

				$status='success';
				$uploading=FALSE;
				$imageSrc='assets/Sunset.jpg';
				
				include('templates/image.php'); 

				$status='error';
				$imageSrc='assets/Winter.jpg';
				
				include('templates/image.php'); 
				
				$status='check';
				$imageSrc='assets/Water lilies.jpg';

				include('templates/image.php'); 	

				$status='unchecked';
				
				include('templates/image.php'); 

				$status=NULL;
				$rename=TRUE;

				include('templates/image.php'); 

				$rename=FALSE;

				include('templates/image.php'); 	
				include('templates/image.php'); 
				
			?>	
		</div>
	</div>
</div>
<div id="footer">
<?php
	include_once('templates/footer-bar.php'); 	
?>
</div>
<?php 
	include_once('templates/directory-modal.php');
	include_once('templates/image-preview.php');
	include_once('templates/slideshow.php');
?>
<script src="../vendor/lodash/lodash.min.js"></script>
<script src="../vendor/jquery-3.3.1/jquery.min.js"></script>
<script src="../vendor/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});
$(document).keypress(function(event){
	if(event.which==120) {
		$(`.slideShow-container`).hide();
	}
});
</script>
</body>
</html>
