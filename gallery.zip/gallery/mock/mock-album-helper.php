<?php 
$tooltipData = array(
	'unchecked'=> array(
		'title'=> 'Click to select.',
		'placement'=> 'top',
		'color'=> 'default'
	),
	'check'=> array(
		'title'=> 'Selected.',
		'placement'=> 'top',
		'color'=> 'primary'
	),
	'processing'=> array(
		'title'=> 'Processing...',
		'placement'=> 'top',
		'color'=> 'info'
	),
	'error'=> array(
		'title'=> 'Error.',
		'placement'=> 'top',
		'color'=> 'danger'
	),
	'success'=> array(
		'title'=> 'Success.',
		'placement'=> 'top',
		'color'=> 'success'
	)
);

function setToolTip($data) {
	echo ' title="' . $data['title'] . '" data-toggle="tooltip" data-placement="' . $data['placement'] . '"';
}
?>