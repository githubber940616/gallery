<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Gallery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="vendor/bootstrap-3.3.5-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="vendor/bootstrap-3.3.5-dist/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/rotate.css">
<link rel="stylesheet" href="css/tooltip-theme.css">
<link rel="icon" href="icon.png">
</head>
<body>
<style>
	#container {
		padding: 70px 0;
	}
</style>
<div id="header" class="container"></div>
<div id="container" class="container"></div>
<div id="footer"></div>
<script src="vendor/lodash/lodash.min.js"></script>
<script src="vendor/jquery-3.3.1/jquery.min.js"></script>
<script src="vendor/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
<script src="js/Screen.js"></script>
<script src="js/PathInfo.js"></script>
<script src="js/Hasher.js"></script>
<script src="js/XmlElement.js"></script>
<script src="js/ComponentConfig.js"></script>
<script src="js/ComponentConfigFixer.js"></script>
<script src="js/Component.js"></script>
<script src="js/components/NavigationBarComponent.js"></script>
<script src="js/components/FooterBarComponent.js"></script>
<script src="js/components/StatusMixin.js"></script>
<script src="js/components/ImageComponent.js"></script>
<script src="js/components/ImagePreviewComponent.js"></script>
<script src="js/components/DirectoryModalComponent.js"></script>
<script src="js/components/SlideShowComponent.js"></script>
<script>
var folders = <?php 
	require_once('path.php');
	require_once($path['shared'] . 'FileManager.php');

	$currentFolder = $_GET['name'];
	$fileManager1 = new FileManager($path['root'] . 'Albums');
	$folders = $fileManager1->getFolders();

	if($folders) {
		foreach ($folders as $folder) {
			if($currentFolder !== $folder) {
				$newFolders[] = $folder;
			}
		}		
	}
	
	echo json_encode($newFolders);
?>;
var images = <?php 
	$albums = $path['root'] . 'Albums';
	$directory = $albums . '/' . $currentFolder;
	$fileManager2 = new FileManager($directory);
	$filterIn = array('png', 'jpg', 'bmp');
	$images = $fileManager2->getFiles($filterIn);

	if($images) {
		foreach ($images as $image) {
			$newImages[] = array(
				'name'=> $image,
				'src'=> $directory . '/' . $image,
				'folder'=> $currentFolder,
			);
		}		
	}

	echo json_encode($newImages);
?>;
var ALBUMS = "<?php echo $albums; ?>";
var CURRENT_FOLDER = "<?php echo $currentFolder; ?>";
</script>
<script src="album.js"></script>
</body>
</html>